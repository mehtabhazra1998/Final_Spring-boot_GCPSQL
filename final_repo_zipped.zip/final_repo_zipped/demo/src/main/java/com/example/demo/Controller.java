package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
// import org.springframework.http.MediaType;

@RestController
// @RequestMapping(value = "/t", produces = { MediaType.APPLICATION_JSON_VALUE })
public class Controller {

    @Autowired
    private TutorialRepository tutorialRepository;

    @GetMapping("/hi")
    public String Hi(){
        return "Hi";
    }
    @PostMapping("/tutorials")
    public String createTutorial(@RequestBody String tutorial)
    {
        try {
            System.out.print("Got here");
            JSONObject jsonObject= new JSONObject(tutorial);
            String title=jsonObject.get("title").toString();
            String description=jsonObject.get("description").toString();
            String published=jsonObject.get("published").toString();
            tutorialRepository.save(new Tutorial(title,description,published));
            return "Done";
        }catch (Exception e)
        {
            System.out.print(e);
            return "Sorry";
        }
    }

}