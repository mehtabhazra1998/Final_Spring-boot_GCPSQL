package com.example.demo;


import javax.persistence.*;



// #  CREATE TABLE ttutorialssss (idd int not null primary key auto_increment, title varchar(255),description varchar(255), published varchar(255));  FOR GOOGLE CLOUD SQL
@Entity
@Table(name = "ttutorialssss")
public class Tutorial {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idd;
    @Column(name = "title")
    private String title;

    @Column(name = "description")
    private String description;

    @Column(name = "published")
    private String published;

    public Tutorial() {
    
    }
    
}